<?php
include('security.php');
include('includes/header.php');
include('includes/navbar.php'); 

?>


<div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Generic Dishes Requests</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
            <?php
                $query = "SELECT * FROM generic_dishes_requests";
                $query_run = mysqli_query($connection, $query);
            ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Cook Id</th>
                            <th>Generic Dish Name</th>
                            <th>Category</th>
                            <th>Mean Price</th>
                            <th>Date Added</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if(mysqli_num_rows($query_run) > 0)        
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                        ?>
                            <tr>
                                <td><?php  echo $row['cook_id']; ?></td>
                                <td><?php  echo $row['gendish_name']; ?></td>
                                <td><?php  echo $row['category']; ?></td>
                                <td><?php  echo $row['mean_price']; ?></td>
                                <td><?php  echo $row['_added']; ?></td>
                                <td>
                                    <form action="code.php" method="post">
                                        <input type="hidden" name="request_id" value="<?php echo $row['request_id']; ?>">
                                        <input type="hidden" name="cook_id" value="<?php echo $row['cook_id']; ?>">
                                        <input type="hidden" name="gendish_name" value="<?php echo $row['gendish_name']; ?>">
                                        <input type="hidden" name="category" value="<?php echo $row['category']; ?>">
                                        <input type="hidden" name="mean_price" value="<?php echo $row['mean_price']; ?>">
                                        <input type="hidden" name="_added" value="<?php echo $row['_added']; ?>">
                                        <button type="submit" name="addbtn" class="btn btn-danger"> ACCEPT</button>
                                    </form>
                                </td>
                            </tr>
                        <?php
                            } 
                        }
                        else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
    

<?php
include('includes/scripts.php');

?>