<?php
include('security.php');

if(isset($_POST['registerbtn']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];

    $email_query = "SELECT * FROM register WHERE email='$email' ";
    $email_query_run = mysqli_query($connection, $email_query);
    if(mysqli_num_rows($email_query_run) > 0)
    {
        $_SESSION['status'] = "Email Already Taken. Please Try Another one.";
        $_SESSION['status_code'] = "error";
        header('Location: register.php');  
    }
    else
    {
        if($password === $cpassword)
        {
            $query = "INSERT INTO register (username,email,password) VALUES ('$username','$email','$password')";
            $query_run = mysqli_query($connection, $query);
            
            if($query_run)
            {
                // echo "Saved";
                $_SESSION['status'] = "Admin Profile Added";
                $_SESSION['status_code'] = "success";
                header('Location: register.php');
            }
            else 
            {
                $_SESSION['status'] = "Admin Profile Not Added";
                $_SESSION['status_code'] = "error";
                header('Location: register.php');  
            }
        }
        else 
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            $_SESSION['status_code'] = "warning";
            header('Location: register.php');  
        }
    }

}
?>

<?php
include('security.php');


if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $password = $_POST['edit_password'];

    $query = "UPDATE register SET username='$username', email='$email', password='$password' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: register.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: register.php'); 
    }
}

?>

<?php
include('security.php');

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM register WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
        header('Location: register.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
        header('Location: register.php'); 
    }    
}
?>

<?php
include('security.php');

if(isset($_POST['user_block_btn']))
{
    $id = $_POST['delete_id'];
    $value = 1;

    $query = "UPDATE user_account SET blocked= '$value' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is UPDATED";
        $_SESSION['status_code'] = "success";
        header('Location: users.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT UPDATED";       
        $_SESSION['status_code'] = "error";
        header('Location: users.php'); 
    }    
}
?>

<?php
include('security.php');

if(isset($_POST['addbtn']))
{
    $request_id = $_POST['request_id'];
    $cook_id = $_POST['cook_id'];
    $gendish_name = $_POST['gendish_name'];
    $category = $_POST['category'];
    $mean_price = $_POST['mean_price'];
    $_added = $_POST['_added'];

    $dish_query = "SELECT * FROM generic_dishes WHERE gendish_name='$gendish_name' ";
    $dish_query_run = mysqli_query($connection, $dish_query);

        
    $query = "INSERT INTO generic_dishes (gendish_name,category,mean_price,_added) VALUES ('$gendish_name','$category','$mean_price','$_added')";
    $query_run = mysqli_query($connection, $query);
            
     if($query_run)
            {
                // echo "Saved";
                $_SESSION['status'] = "Generic Dish Added";
                $_SESSION['status_code'] = "success";
                header('Location: gendishes.php'); 
     }
    else 
            {
                $_SESSION['status'] = "Generic Dish Not Added";
                $_SESSION['status_code'] = "error";
                header('Location: gendishes.php'); 
            }

 
    $del_query = "DELETE FROM generic_dishes_requests WHERE request_id='$request_id' ";
    $del_query_run = mysqli_query($connection, $del_query);

    if($del_query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
        header('Location: gendishes.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
        header('Location: gendishes.php'); 
    }    

}
?>


<?php
include('security.php');

if(isset($_POST['user_unblock_btn']))
{
    $id = $_POST['delete_id'];
    $value = 0;

    $query = "UPDATE user_account SET blocked= '$value' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is UPDATED";
        $_SESSION['status_code'] = "success";
        header('Location: users.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT UPDATED";       
        $_SESSION['status_code'] = "error";
        header('Location: users.php'); 
    }    
}
?>

<?php
include('security.php');

if(isset($_POST['verify_btn']))
{
    $id = $_POST['cook_id'];
    $value = 1;

    $query = "UPDATE cook SET is_verified= '$value' WHERE cook_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is UPDATED";
        $_SESSION['status_code'] = "success";
        header('Location: cook.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT UPDATED";       
        $_SESSION['status_code'] = "error";
        header('Location: cook.php'); 
    }    
}
?>

<?php
include('security.php');

if(isset($_POST['login_btn']))
{
    $email_login = $_POST['emaill']; 
    $password_login = $_POST['passwordd']; 

    $query = "SELECT * FROM register WHERE email='$email_login' AND password='$password_login' LIMIT 1";
    $query_run = mysqli_query($connection, $query);

   if(mysqli_fetch_array($query_run))
   {
        $_SESSION['username'] = $email_login;
        header('Location: index.php');
   } 
   else
   {
        $_SESSION['status'] = "Email / Password is Invalid";
        header('Location: login.php');
   }
    
}
?>