<?php
include('security.php');
include('includes/header.php');
include('includes/navbar.php'); 

?>


<div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Cook Verification</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
            <?php
                $query = "SELECT * FROM cook";
                $query_run = mysqli_query($connection, $query);
                $query2 = "SELECT * FROM cook_kitchen_pics";
                $query_run2 = mysqli_query($connection, $query2);
            ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Cook Id</th>
                            <th>Verified</th>
                            <th>Experience</th>
                            <th>Certified Chef</th>
                            <th>Willing Training</th>
                            <th>Consent Inspection</th>
                            <th>Kitchen Pics</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if(mysqli_num_rows($query_run) > 0)        
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                        ?>
                            <tr>
                                <td><?php  echo $row['cook_id']; ?></td>
                                <td><?php  if($row['is_verified']){
                                    echo 'Yes';
                                }
                                else{
                                    echo 'No';
                                } ?></td>
                                <td><?php  echo $row['experience']; ?></td>
                                <td><?php  if($row['certified_chef']){
                                    echo 'Yes';
                                }
                                else{
                                    echo 'No';
                                } ?></td>
                                <td><?php  if($row['willing_training']){
                                    echo 'Yes';
                                }
                                else{
                                    echo 'No';
                                } ?></td>
                                <td><?php  if($row['consent_inspection']){
                                    echo 'Yes';
                                }
                                else{
                                    echo 'No';
                                } ?></td>
                                
                                <td>
                                <?php
                                    if(mysqli_num_rows($query_run2) > 0)        
                                    {
                                        while($row2 = mysqli_fetch_assoc($query_run2))
                                        {
                                ?>
                                <?php  
                                if($row2['cook_id']=$row['cook_id']){
                                    $image =  $row2['kitchen_pic'];
                                    $imageData = base64_encode(file_get_contents($image));
                                    echo '<img height=200 width=300 src="data:image/jpeg;base64,'.$imageData.'">';
                                }
                               }
                             } ?>
                            </td>

                            <td>
                                    <form action="code.php" method="post">
                                        <input type="hidden" name="cook_id" value="<?php echo $row['cook_id']; ?>">
                                        <button type="submit" name="verify_btn" class="btn btn-danger"> VERIFY </button>
                                    </form>
                                </td>

                            </tr>
                        <?php
                            } 
                        }
                        else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
    

<?php
include('includes/scripts.php');

?>